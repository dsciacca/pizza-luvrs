module.exports = (req, reply) => {
  return reply.view('register');
};
